package com.RenoVirus.AnimatedTabs.Commands;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MainCmdCommandExecutor implements CommandExecutor{
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if (cmd.getName().equalsIgnoreCase("AnimatedTabs") && sender instanceof Player) {
			
			Player player = (Player) sender;
			
			player.sendMessage(ChatColor.RED + "Animated Tabs Help");
			player.sendMessage(ChatColor.YELLOW + "~~~~~~~~~~~~~~~~~~~~~~~~~");
			player.sendMessage(ChatColor.GREEN + "/AnimatedTabs reload");
			player.sendMessage(ChatColor.GREEN + "/TabHeader");
		}
		
		return false;
	}
	
}